package com.example.metchantloginapp

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity



class LoginActivity : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var checkboxRemember: CheckBox
    private lateinit var tvError: TextView

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        checkboxRemember = findViewById(R.id.checkboxRemember)
        tvError = findViewById(R.id.tvError)

        val sharedPref = getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE)
        val savedUsername = sharedPref.getString("username", null)
        val savedPassword = sharedPref.getString("password", null)

        if (savedUsername != null && savedPassword != null) {
            etUsername.setText(savedUsername)
            etPassword.setText(savedPassword)
            checkboxRemember.isChecked = true
        }

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (username.isEmpty()) {
                tvError.text = "Please enter your username."
                tvError.visibility = TextView.VISIBLE
                return@setOnClickListener
            }

            if (password.isEmpty()) {
                tvError.text = "Please enter your password."
                tvError.visibility = TextView.VISIBLE
                return@setOnClickListener
            }

            if (username == "merchant" && password == "1234") {
                tvError.visibility = TextView.GONE
                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()

                with(sharedPref.edit()) {
                    if (checkboxRemember.isChecked) {
                        putString("username", username)
                        putString("password", password)
                    } else {
                        clear()
                    }
                    apply()
                }

            } else {
                tvError.text = "Invalid username or password!"
                tvError.visibility = TextView.VISIBLE
            }
        }
    }
}
